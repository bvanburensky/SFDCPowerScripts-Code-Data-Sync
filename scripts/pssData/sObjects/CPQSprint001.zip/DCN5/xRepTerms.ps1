 
$aReplace = @()


# $aReplace += @{from = "'NET30'"; to = "'Due on receipt'"; }
#$aReplace += @{from = "'a6ADo000000snZpMAI'"; to = "'a6ADo000000snZqMAI'"; }
#$aReplace += @{from = "',0'"; to = "',1'"; }
#$aReplace += @{from = "'800Do000000xgg4IAA'"; to = "'800Do000000xgfQIAQ'"; }
#$aReplace += @{from = "',,'"; to = "',Backlog,'"; }

return $aReplace
 

